package com.acme.test;

import java.util.HashSet;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.acme.test.Item.Category;

/**
 * Unit tests for the Item class.
 */
public class ItemTest {
   
   private Item banana;
   private Item banana2;
   private int maxId;
   
   /**
    * Test setup. This method must not be modified.
    */
   @Before
   public void setUp() {
      banana = new Item(0, "banana", "sold in bunches", Category.Food);
      banana2 = new Item(0, "banana", "sold in bunches", Category.Food);
   }
   
   @Test
   public void testEquality() {
      Assert.assertEquals(banana, banana2);
   }
   
   @Test
   public void cannotAddDuplicate() {
      final HashSet<Item> items = new HashSet<Item>();
      items.add(banana);
      items.add(banana2);
      Assert.assertEquals(1, items.size());
   }
   
   @Test
   public void canGetItems() throws Exception {
      Thread t1 = new Thread(new Runnable() {

         public void run() {
            for (int i = 0; i < 100; i++) {
               Item item = new Item(Item.getNextSequenceNumber(), "name", "description", Category.Food);
               maxId = Math.max(maxId, item.getId());
            }
         }
         
      });
      Thread t2 = new Thread(new Runnable() {

         public void run() {
            for (int i = 0; i < 100; i++) {
               Item item = new Item(Item.getNextSequenceNumber(), "name", "description", Category.Food);
               maxId = Math.max(maxId, item.getId());
            }
         }
         
      });
      t1.start();
      t2.start();
      Thread.sleep(1000);
      Assert.assertEquals(200,  maxId);
   }
}
