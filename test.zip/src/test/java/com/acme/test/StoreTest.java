/**
 * 
 */
package com.acme.test;

import java.util.Iterator;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.acme.test.Item.Category;

/**
 * Unit test for Store object.
 * @author pherold
 */
public class StoreTest {
   private Store store;
   
   private Item banana;
   private Item orange;
   private Item shirt;
   private Item ipad;
   private Item video;
   
   @Before
   public void setUp() {
      store = new Store();
      
      banana = new Item(0, "banana", "sold in bunches", Category.Food);
      orange = new Item(0, "orange", "sold by the dozen", Category.Food);
      shirt = new Item(0, "shirt", "made by Izod", Category.Clothing);
      ipad = new Item(0, "apple", "16GB, white", Category.Electronics);
      video = new Item(0, "Ironman 3", "3rd in the series", Category.Entertainment);
      
      store.addItem(banana);
      store.addItem(orange);
      store.addItem(shirt);
      store.addItem(ipad);
      store.addItem(video);
      
   }
   
   /**
    * Ensures that duplicate items cannot be added to the store.
    * @throws Exception
    */
   @Test
   public void cannotAddDuplicateItems() throws Exception {
      Assert.assertFalse(store.addItem(((Item) banana.clone()))); // can't add a second banana (get it?)
   }
   
   /**
    * Tests if the store contains an item.
    * @throws Exception
    */
   @Test
   public void storeContains() throws Exception {
      final Item ipad2 = (Item) ipad.clone();
      Assert.assertTrue(store.hasItem(ipad2));
   }
   
   /**
    * Tests that the items are sorted.
    * @throws Exception
    */
   @Test
   public void canSortStore() throws Exception {
      final Item[] orderedItems = new Item[] { shirt, banana, orange, ipad, video };
      int i = 0;
      final Iterator<Item> items = store.getItems();
      
      while (items.hasNext()) {
         final Item item = items.next();
         Assert.assertTrue(item == orderedItems[i++]);
      }
      
   }
   
}
