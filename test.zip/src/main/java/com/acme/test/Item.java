package com.acme.test;

/**
 * Immutable class which represents an item for sale in an online store.
 */
public class Item implements Cloneable {
   public enum Category {
      Clothing,
      Electronics,
      Entertainment,
      Food
   }
   
   private int id;
   private final String name;
   private final String description;
   private final Category category;
   private static int sequenceNum = 0;

   public Item(final int id, final String name, final String description, final Category category) {
	   this.id = id;
      this.name = name;
      this.description = description;
      this.category = category;
   }
   
   /**
    * Gets the generated id.
    * @return int
    */
   public int getId() {
      return id;
   }
   
   /**
    * Gets the item name.
    * @return String
    */
   public String getName() {
      return name;
   }
   
   /**
    * Gets the item description.
    * @return String
    */
   public String getDescription() {
      return description;
   }
   
   /**
    * Gets the category for the item.
    * @return Category
    */
   public Category getCategory() {
      return category;
   }
   
   /**
    * (override)
    * @see java.lang.Object#clone()
    */
   @Override
   public Object clone() {
      return new Item(getId(), getName(), getDescription(), getCategory());
   }
   
   public static int getNextSequenceNumber() {
      sequenceNum += 1;
      return sequenceNum;
   }
   
}
